import 'package:flutter/material.dart';

// ============================================================================
// POR QUE ESSE WIDGET EXISTE? (o "problema" antes da solução)
// ============================================================================
// A prova pede DOIS botões: "+ Temperatura" e "- Temperatura".
// Sem widget reutilizável, você escreveria isso DUAS VEZES:
//
//   ElevatedButton(
//     onPressed: _aumentar,
//     child: Row(children: [Icon(Icons.add), Text('Temperatura')]),
//   )
//   ElevatedButton(
//     onPressed: _diminuir,
//     child: Row(children: [Icon(Icons.remove), Text('Temperatura')]),
//   )
//
// Repare: os dois botões são "quase iguais". Só muda o ÍCONE, a COR e
// a AÇÃO que executam. Toda vez que você percebe "estou copiando e
// colando um bloco de widget e só mudando um detalhezinho", é sinal de
// que aquilo deveria virar um widget reutilizável.
//
// A solução: criar UMA classe (BotaoTemperatura) que recebe esses
// "detalhes que mudam" como PARÂMETROS, e usar essa classe duas vezes.
// ============================================================================

class BotaoTemperatura extends StatelessWidget {
  // --------------------------------------------------------------------
  // Por que "extends StatelessWidget" e não "StatefulWidget"?
  // --------------------------------------------------------------------
  // Esse widget, sozinho, NÃO guarda nenhum valor que muda por conta
  // própria. Ele não sabe (e não precisa saber) qual é a temperatura
  // atual. Ele só sabe: "quando alguém me clicar, eu aviso quem me
  // criou, chamando a função que me passaram". Quem de fato guarda e
  // altera a temperatura é a TELA (que veremos depois), não o botão.
  // Por isso ele é Stateless: não tem "vida própria".

  // --------------------------------------------------------------------
  // CADA PARÂMETRO, um de cada vez:
  // --------------------------------------------------------------------

  // 1) O ícone que aparece dentro do botão (ex: Icons.add ou Icons.remove).
  //    Tipo "IconData" é o tipo de dado que TODO ícone do Flutter tem.
  final IconData icone;

  // 2) O texto que aparece ao lado do ícone (ex: "+ Temperatura").
  //    Tipo "String" — simplesmente um texto.
  final String rotulo;

  // 3) A COR de fundo do botão. Tipo "Color" — permite diferenciar
  //    visualmente o botão de aumentar (ex: laranja) do de diminuir
  //    (ex: azul), sem precisar criar duas classes de botão diferentes.
  final Color cor;

  // 4) A função que deve rodar quando o botão for clicado.
  //    "VoidCallback" é só um apelido do Dart pra "uma função que não
  //    recebe nada e não devolve nada" — exatamente o formato de
  //    onPressed de qualquer botão do Flutter.
  //    ESSA é a parte mais importante pra entender reutilização: o
  //    BOTÃO não sabe SE vai aumentar ou diminuir a temperatura — ele só
  //    executa a função que a tela mandou pra ele. A "lógica de verdade"
  //    (somar ou subtrair 1 grau) mora na tela, não aqui.
  final VoidCallback aoClicar;

  // --------------------------------------------------------------------
  // O construtor: aqui é onde você "obriga" quem for usar esse widget a
  // fornecer os 4 valores acima. "required" = obrigatório.
  // --------------------------------------------------------------------
  const BotaoTemperatura({
    super.key,
    required this.icone,
    required this.rotulo,
    required this.cor,
    required this.aoClicar,
  });

  // --------------------------------------------------------------------
  // build(): a "receita visual" de como esse widget se desenha.
  // Isso roda toda vez que o Flutter precisa (re)desenhar esse botão.
  // --------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      // onPressed recebe DIRETAMENTE o "aoClicar" que veio de fora.
      // Ou seja: quando o usuário aperta esse botão físico na tela,
      // quem realmente roda é a função que a TELA definiu, não uma
      // lógica escrita aqui dentro do widget.
      onPressed: aoClicar,

      style: ElevatedButton.styleFrom(
        // backgroundColor usa a cor que veio como parâmetro — por isso
        // o mesmo widget consegue ser laranja numa chamada e azul
        // noutra, sem duplicar código.
        backgroundColor: cor,
        foregroundColor: Colors.white, // cor do texto/ícone dentro do botão
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),

      // O CONTEÚDO do botão (o que aparece dentro dele) é montado com
      // um Row, porque queremos ícone + texto lado a lado.
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icone), // usa o ícone recebido por parâmetro
          const SizedBox(width: 8), // um respiro entre ícone e texto
          Text(rotulo), // usa o texto recebido por parâmetro
        ],
      ),
    );
  }
}

// ============================================================================
// RESUMO DO PADRÃO (isso vale pra QUALQUER widget reutilizável que você
// for criar em qualquer prova, não só nessa):
//
// 1. Ache o que se REPETE visualmente (mesma "forma", dados diferentes).
// 2. Liste o que MUDA de uma repetição pra outra -> isso vira parâmetro.
// 3. Liste o que NÃO muda -> isso fica fixo dentro do build().
// 4. Se o widget só EXIBE coisas e não controla nada sozinho -> Stateless.
// 5. As AÇÕES (o que acontece ao clicar) quase sempre são passadas como
//    parâmetro do tipo VoidCallback, e quem executa a lógica de verdade
//    é a tela que criou o widget — não o widget em si.
// ============================================================================
