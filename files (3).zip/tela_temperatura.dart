import 'package:flutter/material.dart';
import '../widgets/botao_temperatura.dart';

class TelaTemperatura extends StatefulWidget {
  const TelaTemperatura({super.key});

  @override
  State<TelaTemperatura> createState() => _TelaTemperaturaState();
}

class _TelaTemperaturaState extends State<TelaTemperatura> {
  // Variável de estado: guarda a temperatura atual, começando em 20,
  // como a prova pede. É "int" porque a prova só trabalha com graus
  // inteiros (20°C, 21°C...), sem casas decimais.
  int _temperatura = 20;

  // --------------------------------------------------------------------
  // Método que aumenta a temperatura em 1°C.
  // --------------------------------------------------------------------
  void _aumentar() {
    setState(() {
      // "if" simples: só aumenta se ainda não estiver no teto (30).
      // Poderíamos usar clamp() também, mas um "if" comum é mais fácil
      // de justificar numa prova se o professor perguntar "por que
      // você fez assim" — mostra que você entende a regra, não só
      // copiou uma função pronta.
      if (_temperatura < 30) {
        _temperatura++; // equivale a: _temperatura = _temperatura + 1;
      }
    });
  }

  void _diminuir() {
    setState(() {
      if (_temperatura > 16) {
        _temperatura--; // equivale a: _temperatura = _temperatura - 1;
      }
    });
  }

  // --------------------------------------------------------------------
  // Getter para a MENSAGEM da situação da sala (item B da prova).
  // --------------------------------------------------------------------
  // Um "getter" é uma propriedade calculada na hora — toda vez que você
  // escrever "_mensagemSituacao" em algum lugar, o Dart executa esse
  // bloco de novo e devolve o resultado atualizado. Isso garante que a
  // mensagem NUNCA fique "desatualizada" em relação à temperatura atual,
  // sem você precisar lembrar de atualizar duas variáveis toda vez.
  String get _mensagemSituacao {
    if (_temperatura < 20) {
      return 'Sala fria';
    } else if (_temperatura <= 25) {
      // já sabemos que não é < 20 (checado acima), então aqui
      // "<= 25" cobre exatamente a faixa "entre 20 e 25"
      return 'Temperatura agradável';
    } else {
      return 'Sala quente';
    }
  }

  // Mesma lógica, mas devolvendo uma COR em vez de texto — pra pintar o
  // painel de acordo com a situação (deixa a interface mais clara,
  // não é exigência explícita, mas ajuda visualmente e mostra domínio
  // do conceito de "valor calculado a partir do estado").
  Color get _corSituacao {
    if (_temperatura < 20) return Colors.blue.shade100;
    if (_temperatura <= 25) return Colors.green.shade100;
    return Colors.red.shade100;
  }

  @override
  Widget build(BuildContext context) {
    // --------------------------------------------------------------------
    // MediaQuery — item C da prova ("utilize MediaQuery ou LayoutBuilder")
    // --------------------------------------------------------------------
    // MediaQuery.of(context) devolve informações sobre a TELA do
    // dispositivo (largura, altura, etc). Aqui pegamos a LARGURA da
    // tela pra decidir se aumentamos o tamanho da fonte em telas
    // maiores (tablets) — é um uso simples, só pra cumprir a exigência
    // de "adaptar" algo com base no tamanho da tela.
    final larguraTela = MediaQuery.of(context).size.width;
    final ehTelaGrande = larguraTela > 600; // tablets costumam passar disso

    return Scaffold(
      appBar: AppBar(title: const Text('Controle da Sala')),

      // SingleChildScrollView: permite rolar a tela se o conteúdo não
      // couber (exigência de responsividade do item C).
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        // Column organiza os widgets filhos um EMBAIXO do outro
        // (verticalmente). É o widget mais comum pra montar uma tela.
        child: Column(
          children: [
            // ------------------------------------------------------------
            // Painel com a temperatura e a situação da sala.
            // ------------------------------------------------------------
            Container(
              width: double.infinity, // ocupa toda a largura disponível
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _corSituacao, // usa o getter definido acima
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  // Texto grande com o valor da temperatura.
                  // O "$_temperatura" dentro da string insere o valor da
                  // variável ali no meio do texto (interpolação).
                  Text(
                    '$_temperatura°C',
                    style: TextStyle(
                      // Aqui usamos "ehTelaGrande" (calculado com
                      // MediaQuery lá em cima) pra decidir o tamanho da
                      // fonte: 64 em tablets, 48 em celulares.
                      fontSize: ehTelaGrande ? 64 : 48,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8), // espaço vertical de 8 pixels
                  // Texto da situação, usando o getter _mensagemSituacao.
                  Text(
                    _mensagemSituacao,
                    style: const TextStyle(fontSize: 20),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ------------------------------------------------------------
            // AQUI está a reutilização do widget que criamos:
            // usamos BotaoTemperatura DUAS VEZES, mudando só os
            // parâmetros (ícone, rótulo, cor e a função a executar).
            // Isso é exatamente o padrão explicado no arquivo do widget.
            // ------------------------------------------------------------
            Row(
              children: [
                // Expanded faz cada botão ocupar metade da largura da
                // Row (já que temos 2 Expanded dentro da mesma Row),
                // evitando que um botão fique gigante e o outro pequeno.
                Expanded(
                  child: BotaoTemperatura(
                    icone: Icons.remove, // ícone de "-"
                    rotulo: '- Temperatura',
                    cor: Colors.blueGrey,
                    // Aqui é o ponto-chave: NÃO escrevemos a lógica de
                    // diminuir aqui dentro. Só apontamos qual FUNÇÃO da
                    // tela deve ser chamada quando esse botão for clicado.
                    aoClicar: _diminuir,
                  ),
                ),
                const SizedBox(width: 12), // espaço horizontal entre os botões
                Expanded(
                  child: BotaoTemperatura(
                    icone: Icons.add, // ícone de "+"
                    rotulo: '+ Temperatura',
                    cor: Colors.deepOrange,
                    aoClicar: _aumentar,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
