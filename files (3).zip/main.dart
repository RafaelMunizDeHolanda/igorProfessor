import 'package:flutter/material.dart';
import 'pages/tela_temperatura.dart';

void main() {
  // runApp: manda o Flutter desenhar o widget MyApp como raiz do app.
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Controle de Temperatura',
      debugShowCheckedModeBanner: false, // tira a faixa vermelha "DEBUG"
      theme: ThemeData(
        colorSchemeSeed: Colors.deepOrange,
        useMaterial3: true,
      ),
      // home: qual widget/tela abre primeiro quando o app inicia.
      home: const TelaTemperatura(),
    );
  }
}
