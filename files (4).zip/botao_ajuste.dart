import 'package:flutter/material.dart';

// Mesmo padrão do BotaoTemperatura que já vimos: recebe ícone, cor e a
// função a executar. Serve pra qualquer botão de "ajustar um valor".
class BotaoAjuste extends StatelessWidget {
  final IconData icone;
  final Color cor;
  final VoidCallback aoClicar;

  const BotaoAjuste({
    super.key,
    required this.icone,
    required this.cor,
    required this.aoClicar,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton.filled(
      onPressed: aoClicar,
      icon: Icon(icone),
      style: IconButton.styleFrom(backgroundColor: cor, foregroundColor: Colors.white),
    );
  }
}
