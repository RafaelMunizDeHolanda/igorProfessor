import 'package:flutter/material.dart';
import 'tela_confirmacao.dart';

class TelaCadastroSimples extends StatefulWidget {
  const TelaCadastroSimples({super.key});

  @override
  State<TelaCadastroSimples> createState() => _TelaCadastroSimplesState();
}

class _TelaCadastroSimplesState extends State<TelaCadastroSimples> {
  final TextEditingController _nomeController = TextEditingController();

  @override
  void dispose() {
    _nomeController.dispose();
    super.dispose();
  }

  // ==========================================================================
  // O PADRÃO COMPLETO, PASSO A PASSO
  // ==========================================================================
  void _continuar() {
    // PASSO 1 — pegar o texto digitado e tirar espaços em branco das
    // pontas com .trim(). Isso evita que alguém digite só " " (espaço)
    // e o app aceite como se fosse um nome válido.
    final nome = _nomeController.text.trim();

    // PASSO 2 — a VALIDAÇÃO em si: um "if" simples verificando se a
    // string está vazia. .isEmpty é uma propriedade de qualquer String.
    if (nome.isEmpty) {
      // PASSO 3 — SnackBar: uma mensagem que aparece embaixo da tela por
      // alguns segundos e some sozinha.
      //
      // ScaffoldMessenger.of(context) é o "gerenciador" responsável por
      // mostrar SnackBars na tela ATUAL. Ele existe porque, tecnicamente,
      // um SnackBar não é filho direto da árvore de widgets que você
      // escreve — ele "flutua" por cima de tudo, então precisa desse
      // "mensageiro" pra ser exibido corretamente.
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Informe o nome antes de continuar.'),
        ),
      );

      // PASSO 4 — O RETURN é a parte que todo mundo esquece!
      // Sem esse "return" aqui, o código continuaria rodando e
      // chamaria o Navigator.push MESMO com o campo vazio — o SnackBar
      // apareceria, mas a tela abriria do mesmo jeito, o que anula toda
      // a validação. O "return" INTERROMPE a função _continuar() aqui,
      // impedindo que o código abaixo seja executado.
      return;
    }

    // PASSO 5 — Esse trecho SÓ RODA se o "if" acima NÃO tiver entrado
    // (ou seja, se nome.isEmpty for false — o campo está preenchido).
    // Por isso chamamos de "navegação condicional": o Navigator.push
    // só acontece dependendo do resultado da validação.
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TelaConfirmacao(nome: nome),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _continuar,
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
  }
}
