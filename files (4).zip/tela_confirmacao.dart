import 'package:flutter/material.dart';

class TelaConfirmacao extends StatelessWidget {
  final String nome;

  const TelaConfirmacao({super.key, required this.nome});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Confirmação')),
      body: Center(
        child: Text('Bem-vindo(a), $nome!', style: const TextStyle(fontSize: 20)),
      ),
    );
  }
}
