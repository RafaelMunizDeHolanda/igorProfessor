import 'package:flutter/material.dart';
import '../widgets/botao_ajuste.dart';

// ============================================================================
// ESSE ARQUIVO RESUME O QUE SE REPETE NAS 3 PROVAS ORIGINAIS:
// Pet Care, Central de Eventos, Controle de Temperatura.
// Domínio diferente (volume do som), mesma ESTRUTURA de raciocínio.
// ============================================================================

class TelaControleSom extends StatefulWidget {
  const TelaControleSom({super.key});

  @override
  State<TelaControleSom> createState() => _TelaControleSomState();
}

class _TelaControleSomState extends State<TelaControleSom> {
  // PADRÃO 1 — variável de estado com valor inicial definido
  // (igual: energia=50, fome=50, temperatura=20)
  int _volume = 40;

  // PADRÃO 2 — método que altera o estado DENTRO de setState,
  // respeitando um limite mínimo e máximo.
  // (igual: clamp/if na energia, fome e temperatura)
  void _aumentar() {
    setState(() {
      if (_volume < 100) _volume += 10;
    });
  }

  void _diminuir() {
    setState(() {
      if (_volume > 0) _volume -= 10;
    });
  }

  // PADRÃO 3 — getter que calcula uma MENSAGEM a partir do estado atual,
  // usando if/else if por faixas de valor.
  // (igual: "Sala fria/agradável/quente", "planta precisa de água/bem
  // cuidada/excesso", situação da missão)
  String get _situacao {
    if (_volume <= 30) return 'Volume baixo';
    if (_volume <= 70) return 'Volume moderado';
    return 'Volume alto';
  }

  // PADRÃO 4 — cor calculada a partir do estado, pra mudar a
  // aparência automaticamente (igual: "aparência muda quando a energia
  // chega a 20 ou menos" do Pet Care).
  Color get _corPainel {
    if (_volume <= 30) return Colors.blue.shade50;
    if (_volume <= 70) return Colors.green.shade50;
    return Colors.red.shade50;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Controle de Som')),
      // PADRÃO 5 — rolagem pra evitar overflow (sempre presente)
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Painel que muda de cor com AnimatedContainer — igual ao
            // conceito usado no Pet Care e nas atividades de revisão.
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _corPainel,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Text('$_volume%', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(_situacao, style: const TextStyle(fontSize: 18)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // PADRÃO 6 — widget reutilizável usado 2x, mudando parâmetros
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                BotaoAjuste(icone: Icons.remove, cor: Colors.blueGrey, aoClicar: _diminuir),
                const SizedBox(width: 20),
                BotaoAjuste(icone: Icons.add, cor: Colors.deepOrange, aoClicar: _aumentar),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
