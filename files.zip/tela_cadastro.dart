import 'package:flutter/material.dart';
import 'tela_resumo_cadastro.dart';

// ===========================================================================
// CONCEITO 7: TextEditingController
// ===========================================================================
// Cada TextField que você quer "ler" depois precisa de um controller.
// Pense nele como uma caixinha que fica sincronizada com o que o usuário
// digita. Quando você quiser o texto, é só pegar controller.text.
// ===========================================================================

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  // Um controller para cada campo de texto da tela.
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _eventoInteresseController =
      TextEditingController();

  // -------------------------------------------------------------------------
  // Boa prática (não é nota extra, mas evita "vazamento de memória"):
  // sempre que você cria um Controller, deve "descartá-lo" quando a tela
  // for fechada, dentro do método dispose().
  // -------------------------------------------------------------------------
  @override
  void dispose() {
    _nomeController.dispose();
    _emailController.dispose();
    _eventoInteresseController.dispose();
    super.dispose();
  }

  void _salvarCadastro() {
    // -------------------------------------------------------------------------
    // CONCEITO 8: passar dados entre telas via construtor
    // -------------------------------------------------------------------------
    // Criamos a TelaResumoCadastro já "recheada" com os dados lidos dos
    // controllers. Não existe mágica aqui: é só passar valores de texto
    // (Strings) num construtor normal de classe.
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TelaResumoCadastro(
          nome: _nomeController.text,
          email: _emailController.text,
          eventoInteresse: _eventoInteresseController.text,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro de Visitante')),
      // SingleChildScrollView evita overflow se o teclado abrir e
      // empurrar o conteúdo (muito comum em telas de formulário).
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'E-mail',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _eventoInteresseController,
              decoration: const InputDecoration(
                labelText: 'Evento de interesse',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _salvarCadastro,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Salvar cadastro'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
