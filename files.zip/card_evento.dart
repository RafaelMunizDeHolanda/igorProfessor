import 'package:flutter/material.dart';
import '../models/evento.dart';

// ===========================================================================
// CONCEITO: Widget personalizado reutilizável (item E da prova)
// ===========================================================================
// Esse widget recebe um Evento pronto (via construtor) e duas FUNÇÕES
// (callbacks) que serão executadas quando o usuário clicar nos botões.
//
// A ideia central: o CardEvento NÃO SABE mexer no estado (não tem setState
// aqui dentro). Ele só "avisa" a tela pai que um botão foi clicado, através
// do onVerInfo() e onInteresse(). Quem realmente altera os dados é a tela
// que criou esse widget (TelaInicio). Isso é um padrão muito comum em Flutter.
// ===========================================================================

class CardEvento extends StatelessWidget {
  final Evento evento;
  final VoidCallback onVerInfo; // função sem parâmetros, sem retorno
  final VoidCallback onInteresse;

  const CardEvento({
    super.key,
    required this.evento,
    required this.onVerInfo,
    required this.onInteresse,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(evento.icone, size: 36, color: Colors.deepPurple),
                const SizedBox(width: 12),
                // Expanded evita overflow horizontal se o nome for grande
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        evento.nome,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text('${evento.local} • ${evento.horario}'),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // Esse Text é o que precisa "reagir" quando interessados mudar.
            // Ele funciona porque toda vez que a tela pai chama setState(),
            // o Flutter reconstrói (chama build de novo) esse CardEvento
            // com o valor atualizado de evento.interessados.
            Text(
              'Interessados: ${evento.interessados}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: onVerInfo,
                  child: const Text('Ver informações'),
                ),
                ElevatedButton(
                  onPressed: onInteresse,
                  child: const Text('Tenho interesse'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
