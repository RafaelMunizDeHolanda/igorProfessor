import 'package:flutter/material.dart';
import '../models/evento.dart';
import '../widgets/card_evento.dart';
import 'tela_cadastro.dart';

// ===========================================================================
// CONCEITO 1: StatefulWidget x State
// ===========================================================================
// Toda tela que precisa MUDAR algo na interface depois de construída
// (aumentar um número, trocar um texto, etc.) precisa ser um
// StatefulWidget. Ele é dividido em duas classes:
//   - TelaInicio: a "casca", quase vazia, só cria o State.
//   - _TelaInicioState: onde realmente moram as variáveis e o build().
// O "_" na frente do nome é convenção do Dart pra dizer "privado a este
// arquivo" — não é obrigatório, mas é o padrão que todo mundo usa.
// ===========================================================================

class TelaInicio extends StatefulWidget {
  const TelaInicio({super.key});

  @override
  State<TelaInicio> createState() => _TelaInicioState();
}

class _TelaInicioState extends State<TelaInicio> {
  // -------------------------------------------------------------------------
  // CONCEITO 2: onde fica o "estado" (os dados que podem mudar)
  // -------------------------------------------------------------------------
  // Essa lista existe UMA vez só, enquanto a tela estiver viva.
  // Cada Evento dentro dela já nasce com interessados: 0 (ver models/evento.dart).
  final List<Evento> _eventos = [
    Evento(
      nome: 'Festival de Tecnologia',
      local: 'Auditório Central',
      horario: '19h',
      descricao: 'Palestras e demonstrações sobre inovação e startups.',
      vagas: 120,
      icone: Icons.memory,
    ),
    Evento(
      nome: 'Feira de Ciências',
      local: 'Ginásio',
      horario: '14h',
      descricao: 'Projetos dos alunos expostos para visitação.',
      vagas: 80,
      icone: Icons.science,
    ),
    Evento(
      nome: 'Show de Talentos',
      local: 'Pátio Coberto',
      horario: '20h',
      descricao: 'Apresentações musicais e teatrais dos alunos.',
      vagas: 200,
      icone: Icons.music_note,
    ),
  ];

  // -------------------------------------------------------------------------
  // CONCEITO 3: alterar SÓ UM item da lista (item C da prova)
  // -------------------------------------------------------------------------
  // Esse é o ponto que mais gente erra: se você usar a MESMA variável para
  // todos os eventos, clicar em um afeta todos. A solução é guardar o
  // estado DENTRO de cada objeto Evento (evento.interessados), e alterar
  // apenas o objeto certo, usando o índice dele na lista.
  void _incrementarInteresse(int index) {
    setState(() {
      // setState() faz duas coisas:
      // 1) executa o código de dentro (aqui, soma 1 no evento certo);
      // 2) avisa o Flutter "os dados mudaram, redesenhe a tela".
      // Sem o setState, o valor até mudaria na memória, mas a tela
      // continuaria mostrando o número antigo.
      _eventos[index].interessados++;
    });
  }

  // -------------------------------------------------------------------------
  // CONCEITO 4: showModalBottomSheet (item B da prova)
  // -------------------------------------------------------------------------
  // É uma "gaveta" que sobe de baixo pra cima. Recebe o BuildContext atual
  // e um builder que devolve o widget a ser mostrado dentro dela.
  void _abrirInformacoes(Evento evento) {
    showModalBottomSheet(
      context: context,
      // isScrollControlled deixa o modal crescer mais que a altura padrão,
      // útil se a descrição for grande (evita overflow dentro do modal)
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min, // ocupa só o espaço necessário
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                evento.nome,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text('Local: ${evento.local}'),
              Text('Horário: ${evento.horario}'),
              const SizedBox(height: 8),
              Text(evento.descricao),
              const SizedBox(height: 8),
              Text('Vagas: ${evento.vagas}'),
              const SizedBox(height: 16),
              // Botão pra fechar o modal: Navigator.pop() sem argumentos
              // "fecha a última coisa aberta" — nesse caso, o modal.
              Center(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Fechar'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // -------------------------------------------------------------------------
  // CONCEITO 5: Navigator.push (item D da prova)
  // -------------------------------------------------------------------------
  // Abre a tela de cadastro "em cima" da atual. O usuário pode voltar com
  // o botão de voltar do app ou um Navigator.pop().
  void _abrirCadastro() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const TelaCadastro()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Central de Eventos')),
      // ---------------------------------------------------------------------
      // CONCEITO 6: evitar overflow com rolagem (item A da prova)
      // ---------------------------------------------------------------------
      // ListView.builder já rola sozinho — não precisa envolver com
      // SingleChildScrollView. Ele também é mais eficiente que um Column
      // dentro de scroll, porque só constrói os itens visíveis na tela.
      body: ListView.builder(
        itemCount: _eventos.length,
        itemBuilder: (context, index) {
          final evento = _eventos[index];
          // Aqui usamos o widget personalizado (CardEvento), passando
          // o evento certo e as duas funções que ele deve chamar.
          return CardEvento(
            evento: evento,
            onVerInfo: () => _abrirInformacoes(evento),
            onInteresse: () => _incrementarInteresse(index),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _abrirCadastro,
        icon: const Icon(Icons.person_add),
        label: const Text('Cadastro'),
      ),
    );
  }
}
