import 'package:flutter/material.dart';

// ===========================================================================
// CONCEITO 9: StatelessWidget que RECEBE dados prontos
// ===========================================================================
// Essa tela não precisa de StatefulWidget porque ela não vai MUDAR nada
// depois de aberta — só exibe o que já veio pronto da tela anterior.
// Os dados chegam como parâmetros obrigatórios no construtor.
// ===========================================================================

class TelaResumoCadastro extends StatelessWidget {
  final String nome;
  final String email;
  final String eventoInteresse;

  const TelaResumoCadastro({
    super.key,
    required this.nome,
    required this.email,
    required this.eventoInteresse,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro Concluído')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Dados recebidos:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text('Nome: $nome'),
            const SizedBox(height: 8),
            Text('E-mail: $email'),
            const SizedBox(height: 8),
            Text('Evento de interesse: $eventoInteresse'),
            const Spacer(),
            // Navigator.pop volta para a tela anterior (a de cadastro).
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Voltar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
