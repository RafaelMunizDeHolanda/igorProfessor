import 'package:flutter/material.dart';
import 'pages/tela_inicio.dart';

// ===========================================================================
// CONCEITO 0 (o mais básico de todos): void main()
// ===========================================================================
// É a primeira função que o Dart executa. runApp() recebe o widget raiz
// do aplicativo e "planta" ele na tela do dispositivo.
// ===========================================================================
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MaterialApp configura tema, título e qual tela abre primeiro (home).
    return MaterialApp(
      title: 'Central de Eventos',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const TelaInicio(),
    );
  }
}
