import 'package:flutter/material.dart';

// Essa classe é só um "molde" pra guardar os dados de um evento.
// Não é uma exigência explícita da prova, mas ajuda a não ficar
// repetindo 6 variáveis soltas em vários lugares do código.
class Evento {
  final String nome;
  final String local;
  final String horario;
  final String descricao;
  final int vagas;
  final IconData icone;

  // Esse campo NÃO é "final" de propósito: ele precisa mudar
  // toda vez que alguém clicar em "Tenho interesse".
  int interessados;

  Evento({
    required this.nome,
    required this.local,
    required this.horario,
    required this.descricao,
    required this.vagas,
    required this.icone,
    this.interessados = 0, // já nasce com 0, como a prova pede
  });
}
