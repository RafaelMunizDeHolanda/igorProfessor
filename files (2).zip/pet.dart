// ============================================================================
// O QUE É ESSE ARQUIVO?
// ============================================================================
// Isso aqui é o "Model" (se quisermos usar um nome bonito). Na prática,
// é só uma CLASSE que representa um pet: um conjunto de variáveis
// organizadas dentro de um "pacote" com nome (Pet).
//
// Por que criar uma classe em vez de usar variáveis soltas (nome, tipo,
// energia, fome direto no main.dart)?
// Porque assim, se no futuro você precisar de 5 pets em vez de 1, basta
// criar uma List<Pet> — com variáveis soltas isso seria muito mais difícil.
// Não é obrigatório pela prova, mas é uma boa prática que o professor
// costuma valorizar.
// ============================================================================

class Pet {
  // --------------------------------------------------------------------
  // TIPOS DE VARIÁVEIS EM DART — a base de tudo
  // --------------------------------------------------------------------
  // String  -> texto, sempre entre aspas: 'Rex', "Gato"
  // int     -> número inteiro, sem casas decimais: 50, 0, -10
  // double  -> número com casas decimais: 3.14, 0.5
  // bool    -> verdadeiro ou falso: true, false
  //
  // "final" quer dizer: essa variável recebe um valor UMA VEZ (no
  // construtor) e nunca mais muda durante a vida do objeto.
  // Use final para dados que não vão mudar (nome do pet, tipo do pet).
  final String nome;
  final String tipo;

  // Aqui NÃO usamos "final" porque energia e fome VÃO MUDAR quando o
  // usuário clicar em Brincar/Alimentar. Se colocasse "final", o Dart
  // nem deixaria compilar quando tentássemos alterar o valor depois.
  int energia;
  int fome;

  // --------------------------------------------------------------------
  // CONSTRUTOR
  // --------------------------------------------------------------------
  // É a "receita" de como criar um Pet nesse formato:
  //   Pet(nome: 'Rex', tipo: 'Cachorro')
  // "required" significa que é obrigatório informar aquele valor.
  // "this.energia = 50" significa: se ninguém informar, use 50 como padrão.
  // Isso já resolve a exigência da prova: "o pet deverá iniciar com
  // energia 50 e fome 50".
  Pet({
    required this.nome,
    required this.tipo,
    this.energia = 50,
    this.fome = 50,
  });
}
