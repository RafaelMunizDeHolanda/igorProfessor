import 'package:flutter/material.dart';
import '../models/pet.dart';
import 'tela_informacoes.dart';

// ============================================================================
// TextEditingController — explicando com calma
// ============================================================================
// Quando você cria um TextField assim:
//     TextField()
// ele funciona, mas você NUNCA CONSEGUE LER o que o usuário digitou.
// O TextField sozinho só mostra o texto na tela, não guarda ele em
// nenhuma variável que você controle.
//
// Pra "capturar" o texto, você cria um TextEditingController e entrega
// ele pro TextField através da propriedade "controller". A partir
// desse momento, toda letra digitada é refletida dentro do controller,
// e você pode ler com "meuController.text" a qualquer momento.
//
// Analogia: o TextField é a caixinha de digitar na tela; o Controller é
// um "gravador" que fica anotando tudo que passa por ali.
// ============================================================================

class TelaCadastroResponsavel extends StatefulWidget {
  final Pet pet; // recebemos o pet da tela anterior (energia/fome atuais)

  const TelaCadastroResponsavel({super.key, required this.pet});

  @override
  State<TelaCadastroResponsavel> createState() =>
      _TelaCadastroResponsavelState();
}

class _TelaCadastroResponsavelState extends State<TelaCadastroResponsavel> {
  // Um controller para CADA campo de texto da tela. Não dá pra usar
  // um controller só pra dois TextFields diferentes.
  final TextEditingController _nomeResponsavelController =
      TextEditingController();
  final TextEditingController _nomePetController = TextEditingController();
  final TextEditingController _telefoneController = TextEditingController();

  // --------------------------------------------------------------------
  // dispose() — "faxina" de memória
  // --------------------------------------------------------------------
  // Cada TextEditingController que você cria com "TextEditingController()"
  // fica ocupando memória "escutando" o campo de texto. Quando a tela é
  // fechada (o usuário aperta voltar), precisamos avisar o Flutter "pode
  // liberar essa memória, não vou usar mais". Isso é feito dentro do
  // método dispose(), chamando .dispose() em cada controller.
  //
  // Isso NÃO é opcional em projetos sérios — deixar de fazer isso é
  // chamado de "memory leak" (vazamento de memória).
  @override
  void dispose() {
    _nomeResponsavelController.dispose();
    _nomePetController.dispose();
    _telefoneController.dispose();
    super.dispose(); // sempre chame o dispose "pai" por último
  }

  void _salvarCadastro() {
    // --------------------------------------------------------------------
    // Passagem de dados entre telas
    // --------------------------------------------------------------------
    // O Navigator.push abre uma nova tela. O "MaterialPageRoute" define
    // QUAL tela abrir, através do parâmetro "builder", que é uma função
    // que devolve o widget da nova tela já "montado" com os dados certos.
    //
    // Cada valor que a TelaInformacoes precisa (nomeResponsavel, telefone,
    // nomePet, energiaAtual, fomeAtual) é passado como parâmetro do
    // CONSTRUTOR dela — exatamente como você passaria argumentos pra
    // uma função comum.
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TelaInformacoes(
          nomeResponsavel: _nomeResponsavelController.text,
          telefone: _telefoneController.text,
          nomePet: _nomePetController.text,
          energiaAtual: widget.pet.energia,
          fomeAtual: widget.pet.fome,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro do Responsável')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Cada TextField abaixo segue o MESMO padrão:
            // 1) tem um controller associado
            // 2) tem uma decoration só pra ficar visualmente organizado
            TextField(
              controller: _nomeResponsavelController,
              decoration: const InputDecoration(
                labelText: 'Nome do responsável',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _nomePetController,
              decoration: const InputDecoration(
                labelText: 'Nome do pet',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.pets),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _telefoneController,
              // keyboardType muda o teclado que aparece no celular —
              // aqui, um teclado numérico, já que é telefone.
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Telefone',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.phone),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _salvarCadastro,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('Salvar cadastro'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
