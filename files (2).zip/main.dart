import 'package:flutter/material.dart';
import 'pages/tela_pet.dart';

// ============================================================================
// void main() { runApp(...) } — o começo de TODO app Flutter
// ============================================================================
// "void" quer dizer que essa função não devolve nenhum valor, ela só
// EXECUTA uma ação (nesse caso, iniciar o app). runApp() recebe um
// widget e diz pro Flutter "desenhe isso na tela do dispositivo, a
// partir de agora".
// ============================================================================
void main() {
  runApp(const MyApp());
}

// MyApp é o widget "raiz". Ele não desenha nada visualmente por si só —
// só configura coisas globais do app (tema, título, primeira tela).
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pet Care',
      debugShowCheckedModeBanner: false, // remove a faixa "DEBUG" do canto
      theme: ThemeData(
        colorSchemeSeed: Colors.brown,
        useMaterial3: true,
      ),
      // "home" é a tela que abre primeiro quando o app é executado.
      home: const TelaPet(),
    );
  }
}
