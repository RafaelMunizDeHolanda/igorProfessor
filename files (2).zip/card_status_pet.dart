import 'package:flutter/material.dart';

// ============================================================================
// WIDGET PERSONALIZADO REUTILIZÁVEL (exigência do item E da prova)
// ============================================================================
// A ideia: em vez de escrever duas vezes o "bloco visual" que mostra um
// status (uma vez pra energia, outra pra fome), criamos ESSE widget e
// USAMOS ele duas vezes, mudando só os parâmetros. Isso é reutilização.
//
// Repare que essa classe estende StatelessWidget, não StatefulWidget.
// Por quê? Porque o CardStatusPet, sozinho, NÃO controla nada — ele só
// EXIBE um valor que já vem pronto de fora (via construtor). Quem controla
// o valor de verdade é a tela que usa esse widget (TelaPet).
//
// Regra prática pra decidir Stateless x Stateful:
//   - Se o widget só mostra dados que vêm de fora -> StatelessWidget
//   - Se o widget precisa mudar algo sozinho, sem depender de quem o
//     chamou -> StatefulWidget
// ============================================================================

class CardStatusPet extends StatelessWidget {
  // --------------------------------------------------------------------
  // Esses são os "parâmetros" do widget — o que ele PRECISA receber
  // pra saber o que desenhar. São todos "final" porque, uma vez que o
  // widget foi criado com esses valores, eles não mudam por dentro dele
  // (se precisar mudar, quem manda um novo valor é a tela pai, criando
  // o widget de novo com números diferentes).
  // --------------------------------------------------------------------
  final String titulo; // Ex: "Energia" ou "Fome"
  final int valor; // Ex: 50
  final IconData icone; // Ex: Icons.bolt
  final Color cor; // cor do ícone/barra, pra diferenciar energia de fome

  const CardStatusPet({
    super.key,
    required this.titulo,
    required this.valor,
    required this.icone,
    required this.cor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: cor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cor.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Icon(icone, color: cor),
          const SizedBox(width: 10),
          // Expanded faz esse pedaço "esticar" e ocupar o espaço
          // restante da Row, evitando overflow horizontal se o texto
          // for grande.
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(titulo, style: const TextStyle(fontSize: 13)),
                const SizedBox(height: 4),
                // LinearProgressIndicator é uma barrinha de progresso.
                // Ele espera um valor de 0.0 a 1.0, por isso dividimos
                // por 100 (regra de três simples: 50/100 = 0.5 = 50%).
                LinearProgressIndicator(
                  value: valor / 100,
                  color: cor,
                  backgroundColor: cor.withOpacity(0.15),
                  minHeight: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          // Interpolação de String: o $valor dentro das aspas é
          // substituído pelo valor real da variável na hora de exibir.
          Text(
            '$valor%',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ],
      ),
    );
  }
}
