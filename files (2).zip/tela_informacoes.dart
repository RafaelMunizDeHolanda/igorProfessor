import 'package:flutter/material.dart';

// ============================================================================
// Por que essa tela é StatelessWidget e não StatefulWidget?
// ============================================================================
// Regra de ouro: se a tela NÃO tem nenhum botão que muda um valor
// exibido nela mesma (não tem +1, não tem um TextField, nada que precise
// de setState), ela pode ser StatelessWidget. Aqui só exibimos dados que
// já chegaram prontos — não há nada "vivo" pra controlar.
//
// Isso economiza código: não precisamos das duas classes (Widget + State),
// só uma.
// ============================================================================

class TelaInformacoes extends StatelessWidget {
  // Todos "final" porque são dados recebidos de fora e nunca mudam
  // durante a vida desse widget.
  final String nomeResponsavel;
  final String telefone;
  final String nomePet;
  final int energiaAtual;
  final int fomeAtual;

  const TelaInformacoes({
    super.key,
    required this.nomeResponsavel,
    required this.telefone,
    required this.nomePet,
    required this.energiaAtual,
    required this.fomeAtual,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Informações Cadastradas')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Dados do responsável',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            _linhaInfo('Responsável', nomeResponsavel),
            _linhaInfo('Telefone', telefone),
            _linhaInfo('Pet', nomePet),
            const SizedBox(height: 20),
            const Text(
              'Status atual do pet',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            _linhaInfo('Energia', '$energiaAtual%'),
            _linhaInfo('Fome', '$fomeAtual%'),
            const SizedBox(height: 30),
            // Navigator.pop(context) fecha ESSA tela e volta pra
            // anterior. Repare que não precisamos dizer "volte pra
            // TelaCadastroResponsavel" — o Flutter já sabe qual foi a
            // última tela aberta, guarda isso numa "pilha" de telas.
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Voltar'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Esse é um método "auxiliar" só pra não repetir o mesmo Row várias
  // vezes. Não precisa ser um widget separado em outro arquivo — pode
  // ser um método comum dentro da própria classe, como esse aqui.
  Widget _linhaInfo(String rotulo, String valor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Text(
            '$rotulo: ',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          // Expanded evita overflow se o valor for um texto grande
          Expanded(child: Text(valor)),
        ],
      ),
    );
  }
}
