import 'package:flutter/material.dart';
import '../models/pet.dart';
import '../widgets/card_status_pet.dart';
import 'tela_cadastro_responsavel.dart';

// ============================================================================
// StatefulWidget x State — por que duas classes?
// ============================================================================
// TelaPet é só a "casca": o Flutter usa ela pra saber que essa tela EXISTE
// e pra criar o "cérebro" dela (_TelaPetState) quando for necessário.
// Ela mesma não guarda nenhuma variável que muda.
// ============================================================================
class TelaPet extends StatefulWidget {
  const TelaPet({super.key});

  @override
  State<TelaPet> createState() => _TelaPetState();
}

// ============================================================================
// _TelaPetState — aqui é onde a "vida" da tela acontece
// ============================================================================
// O "State<TelaPet>" na herança quer dizer: "esse é o estado de TelaPet".
// Tudo que estiver aqui dentro sobrevive entre uma reconstrução e outra
// da tela (enquanto o setState só redesenha, sem apagar as variáveis).
// ============================================================================
class _TelaPetState extends State<TelaPet> {
  // --------------------------------------------------------------------
  // VARIÁVEL DE ESTADO
  // --------------------------------------------------------------------
  // Criamos UM objeto Pet e guardamos ele numa variável chamada "_pet".
  // O "_" no início do nome é convenção do Dart pra "privado a este
  // arquivo" — ninguém de fora consegue acessar _pet diretamente.
  //
  // Repare: NÃO colocamos "final" aqui, porque, embora o OBJETO _pet em
  // si não vá trocar (não vamos criar um Pet novo), os CAMPOS internos
  // dele (pet.energia, pet.fome) vão mudar. Isso é perfeitamente válido
  // em Dart: você pode ter "final Pet _pet" e mesmo assim alterar
  // _pet.energia, porque "final" trava a REFERÊNCIA, não o conteúdo.
  final Pet _pet = Pet(nome: 'Rex', tipo: 'Cachorro');

  // --------------------------------------------------------------------
  // MÉTODOS QUE ALTERAM O ESTADO
  // --------------------------------------------------------------------
  // Toda função que muda uma variável de estado E precisa refletir isso
  // na tela DEVE estar envolvida em setState(() { ... }).
  //
  // Passo a passo do que acontece quando o usuário clica em "Alimentar":
  // 1) O Flutter chama _alimentar()
  // 2) Entramos no setState
  // 3) Calculamos o novo valor da fome, sem deixar passar de 0
  // 4) Fechamos o setState -> o Flutter agenda um novo build()
  // 5) O build() roda de novo, e a tela mostra o número atualizado
  void _alimentar() {
    setState(() {
      // A função "clamp" trava um número dentro de um intervalo.
      // clamp(0, 100) quer dizer: "se for menor que 0, vira 0; se for
      // maior que 100, vira 100; senão, mantém o valor".
      // Aqui só precisamos garantir o mínimo (a prova não pede máximo
      // pra fome), mas usar clamp(0, 100) não causa nenhum problema.
      _pet.fome = (_pet.fome - 10).clamp(0, 100);
    });
  }

  void _brincar() {
    setState(() {
      _pet.energia = (_pet.energia - 10).clamp(0, 100);
    });
  }

  // --------------------------------------------------------------------
  // "A aparência deverá mudar quando a energia chegar a 20 ou menos"
  // --------------------------------------------------------------------
  // Isso é um requisito do checklist da prova. Resolvemos com um
  // simples "if" que decide qual cor/ícone usar, dependendo do valor
  // atual de energia. Não precisa de nada mais sofisticado que isso.
  Color get _corDoPainel {
    if (_pet.energia <= 20) {
      return Colors.red.shade100; // pet "cansado"
    }
    return Colors.green.shade50; // pet "bem"
  }

  IconData get _iconeDoPet {
    if (_pet.energia <= 20) {
      return Icons.sentiment_very_dissatisfied; // carinha triste
    }
    return Icons.pets; // carinha normal
  }

  // --------------------------------------------------------------------
  // Navegação para o cadastro do responsável (item C da prova)
  // --------------------------------------------------------------------
  void _abrirCadastroResponsavel() {
    Navigator.push(
      context,
      MaterialPageRoute(
        // Passamos o PRÓPRIO objeto _pet pra tela de cadastro, porque
        // ela vai precisar repassar energia/fome atuais pra tela de
        // informações depois (item D da prova pede os valores atuais
        // do pet, não só o que foi digitado no formulário).
        builder: (context) => TelaCadastroResponsavel(pet: _pet),
      ),
    );
  }

  // --------------------------------------------------------------------
  // build() — roda TODA VEZ que o setState é chamado
  // --------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pet Care')),
      // SingleChildScrollView garante que, se o conteúdo for maior que
      // a tela (ex: em celulares pequenos), o usuário consiga rolar em
      // vez de a tela quebrar com overflow (exigência da tela do pet:
      // "deverá permanecer utilizável caso o conteúdo ultrapasse o
      // espaço disponível").
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          // stretch faz os filhos ocuparem toda a largura disponível
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ----------------------------------------------------------
            // Painel com nome, tipo e ícone do pet.
            // AnimatedContainer faz a transição de cor ficar suave
            // (não é obrigatório na prova A, mas deixa a interface mais
            // "viva" e é o mesmo conceito cobrado na Horta Inteligente
            // e na Oficina de Robôs da lista de revisão).
            // ----------------------------------------------------------
            AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _corDoPainel,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Icon(_iconeDoPet, size: 64, color: Colors.brown),
                  const SizedBox(height: 8),
                  Text(
                    _pet.nome,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(_pet.tipo, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // ----------------------------------------------------------
            // Aqui usamos o WIDGET PERSONALIZADO duas vezes, mudando só
            // os parâmetros. Isso é literalmente "reutilização de
            // widget" — o mesmo pedaço de interface, usado com dados
            // diferentes.
            // ----------------------------------------------------------
            CardStatusPet(
              titulo: 'Energia',
              valor: _pet.energia,
              icone: Icons.bolt,
              cor: Colors.orange,
            ),
            CardStatusPet(
              titulo: 'Fome',
              valor: _pet.fome,
              icone: Icons.restaurant,
              cor: Colors.teal,
            ),

            const SizedBox(height: 20),

            // ----------------------------------------------------------
            // Botões de ação — cada um chama um método que faz
            // setState por dentro.
            // ----------------------------------------------------------
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _brincar,
                    icon: const Icon(Icons.sports_esports),
                    label: const Text('Brincar'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _alimentar,
                    icon: const Icon(Icons.restaurant),
                    label: const Text('Alimentar'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _abrirCadastroResponsavel,
              icon: const Icon(Icons.person),
              label: const Text('Cadastro do responsável'),
            ),
          ],
        ),
      ),
    );
  }
}
